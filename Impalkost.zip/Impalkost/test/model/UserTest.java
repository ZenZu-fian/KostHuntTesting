package model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserTest {

    private User user;

    @Before
    public void setUp() {
        user = new User(1, "Andi", "andi@email.com", "12345", "08123456789", "USER");
    }

    @Test
    public void testConstructorAndGetters() {
        assertEquals(1, user.getId());
        assertEquals("Andi", user.getName());
        assertEquals("andi@email.com", user.getEmail());
        assertEquals("12345", user.getPassword());
        assertEquals("08123456789", user.getPhone());
        assertEquals("USER", user.getRole());
    }

    @Test
    public void testSetters() {
        user.setId(2);
        user.setName("Budi");
        user.setEmail("budi@email.com");
        user.setPassword("passwordBaru");
        user.setPhone("0899999999");
        user.setRole("ADMIN");

        assertEquals(2, user.getId());
        assertEquals("Budi", user.getName());
        assertEquals("budi@email.com", user.getEmail());
        assertEquals("passwordBaru", user.getPassword());
        assertEquals("0899999999", user.getPhone());
        assertEquals("ADMIN", user.getRole());
    }

    @Test
    public void testEditProfilWithPassword() {
        boolean result = user.editProfil(
                "new@email.com",
                "Andi Baru",
                "0811111111",
                "newpass",
                "ADMIN"
        );

        assertTrue(result);
        assertEquals("new@email.com", user.getEmail());
        assertEquals("Andi Baru", user.getName());
        assertEquals("0811111111", user.getPhone());
        assertEquals("newpass", user.getPassword());
        assertEquals("ADMIN", user.getRole());
    }

    @Test
    public void testEditProfilWithoutPassword() {
        String oldPassword = user.getPassword();

        boolean result = user.editProfil(
                "update@email.com",
                "Andi Update",
                "0822222222",
                "",
                "USER"
        );

        assertTrue(result);
        assertEquals("update@email.com", user.getEmail());
        assertEquals("Andi Update", user.getName());
        assertEquals("0822222222", user.getPhone());
        assertEquals(oldPassword, user.getPassword()); // password should NOT change
    }

    @Test
    public void testLogoutPengguna() {
        // Just verify it does not throw an exception
        user.logoutPengguna();
    }

    @Test
    public void testToString() {
        String result = user.toString();
        assertTrue(result.contains("Andi"));
        assertTrue(result.contains("andi@email.com"));
        assertTrue(result.contains("USER"));
    }

    @Test
    public void testLoginPenggunaReturnsNull() {
        User result = User.loginPengguna("test@email.com", "12345");
        assertNull(result);
    }

    @Test
    public void testRegisterPenggunaReturnsNull() {
        User result = User.registerPengguna(
                "new@email.com",
                "New User",
                "0810000000",
                "password",
                "USER"
        );
        assertNull(result);
    }
}
