package model;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestOwner {

    private Owner owner;

    @Before
    public void setUp() {
        owner = new Owner();
    }

    @Test
    public void testDefaultConstructor() {
        assertEquals("Owner", owner.getRole());
        assertNotNull(owner.getListKost());
        assertEquals(0, owner.getListKost().size());
    }

    @Test
    public void testParameterizedConstructor() {
        Owner ownerWithParams = new Owner(1, "John Doe", "john@email.com", 
                                          "password123", "081234567890", "1234567890");
        
        assertEquals(1, ownerWithParams.getId());
        assertEquals("John Doe", ownerWithParams.getName());
        assertEquals("john@email.com", ownerWithParams.getEmail());
        assertEquals("password123", ownerWithParams.getPassword());
        assertEquals("081234567890", ownerWithParams.getPhone());
        assertEquals("Owner", ownerWithParams.getRole());
        assertEquals("1234567890", ownerWithParams.getBankAccount());
    }

    @Test
    public void testAddKost() {
        Kost kost = new Kost();
        kost.setName("Test Kost");
        owner.addKost(kost);

        assertEquals(1, owner.getListKost().size());
        assertTrue(owner.getListKost().contains(kost));
    }

    @Test
    public void testRemoveKost() {
        Kost kost = new Kost();
        kost.setName("Test Kost");
        owner.addKost(kost);
        
        assertEquals(1, owner.getListKost().size());
        
        owner.removeKost(kost);
        assertEquals(0, owner.getListKost().size());
    }

    @Test
    public void testMenambahkanDataKos_ValidData() {
        Kost kost = owner.menambahkanDataKos(
            "owner@email.com",
            "Kost Mawar",
            "Jl. Melati No. 5",
            "Bandung",
            "Dekat kampus",
            "Putri",
            "AC, WiFi",
            "1500000"
        );

        assertNotNull(kost);
        assertEquals(1, owner.getListKost().size());
        assertEquals("Kost Mawar", kost.getName());
        assertEquals("Jl. Melati No. 5", kost.getAddress());
        assertEquals("Bandung", kost.getLocation());
        assertEquals("Dekat kampus", kost.getDescription());
        assertEquals("Putri", kost.getType());
        assertEquals("AC, WiFi", kost.getFacilities());
        assertEquals(1500000.0, kost.getPrice(), 0.001);
    }

    @Test
    public void testMenambahkanDataKos_MultipleKost() {
        owner.menambahkanDataKos("owner@email.com", "Kost A", "Jl. A", 
                                 "Jakarta", "Deskripsi A", "Putra", "WiFi", "1000000");
        owner.menambahkanDataKos("owner@email.com", "Kost B", "Jl. B", 
                                 "Bandung", "Deskripsi B", "Putri", "AC", "2000000");

        assertEquals(2, owner.getListKost().size());
    }

    @Test
    public void testMenampilkanDetailKos_KostExists() {
        Kost kost = new Kost();
        kost.setId(1);
        kost.setName("Kost Test");
        kost.setAddress("Jl. Test");
        kost.setPrice(1500000);
        owner.addKost(kost);

        // This will print to console - just testing it doesn't throw exception
        owner.menampilkanDetailKos(1);
        
        // Verify kost is still in the list
        assertEquals(1, owner.getListKost().size());
    }

    @Test
    public void testMenampilkanDetailKos_KostNotExists() {
        // Testing with non-existent ID - should not throw exception
        owner.menampilkanDetailKos(999);
        
        assertEquals(0, owner.getListKost().size());
    }

    @Test
    public void testMenghapusDataKos_ValidId() {
        Kost kost = new Kost();
        kost.setId(1);
        kost.setName("Kost Test");
        owner.addKost(kost);

        assertEquals(1, owner.getListKost().size());
        
        owner.menghapusDataKos("1");

        assertEquals(0, owner.getListKost().size());
    }

    @Test
    public void testMenghapusDataKos_NonExistentId() {
        Kost kost = new Kost();
        kost.setId(1);
        owner.addKost(kost);

        owner.menghapusDataKos("999");

        // Should still have 1 kost since ID doesn't match
        assertEquals(1, owner.getListKost().size());
    }

    @Test
    public void testMengeditDataKos_ValidData() {
        Kost kost = new Kost();
        kost.setName("Kost Anggrek");
        kost.setAddress("Jl. Lama");
        kost.setDescription("Deskripsi lama");
        kost.setType("Putra");
        kost.setFacilities("WiFi");
        kost.setPrice(1000000);
        owner.addKost(kost);

        owner.mengeditDataKos(
            "owner@email.com",
            "Kost Anggrek",
            "Jl. Baru",
            "Lebih luas",
            "Campur",
            "AC, Parkir",
            "2000000"
        );

        Kost edited = owner.getListKost().get(0);
        assertEquals("Kost Anggrek", edited.getName()); // Name shouldn't change
        assertEquals("Jl. Baru", edited.getAddress());
        assertEquals("Lebih luas", edited.getDescription());
        assertEquals("Campur", edited.getType());
        assertEquals("AC, Parkir", edited.getFacilities());
        assertEquals(2000000.0, edited.getPrice(), 0.001);
    }

    @Test
    public void testMengeditDataKos_NonExistentKost() {
        Kost kost = new Kost();
        kost.setName("Kost Existing");
        kost.setPrice(1000000);
        owner.addKost(kost);

        // Try to edit non-existent kost
        owner.mengeditDataKos(
            "owner@email.com",
            "Kost NonExistent",
            "Jl. Baru",
            "Deskripsi",
            "Putra",
            "AC",
            "2000000"
        );

        // Original kost should remain unchanged
        assertEquals(1000000.0, owner.getListKost().get(0).getPrice(), 0.001);
    }

    @Test
    public void testMengelolaKamar() {
        // This method just prints - testing it doesn't throw exception
        owner.mengelolaKamar(1, "Test Room");
        
        // No assertion needed, just verifying no exception
        assertTrue(true);
    }

    @Test
    public void testBankAccountGetterSetter() {
        owner.setBankAccount("9876543210");
        assertEquals("9876543210", owner.getBankAccount());
    }

    @Test
    public void testSetListKost() {
        Kost kost1 = new Kost();
        kost1.setName("Kost 1");
        Kost kost2 = new Kost();
        kost2.setName("Kost 2");
        
        java.util.List<Kost> newList = new java.util.ArrayList<>();
        newList.add(kost1);
        newList.add(kost2);
        
        owner.setListKost(newList);
        
        assertEquals(2, owner.getListKost().size());
        assertTrue(owner.getListKost().contains(kost1));
        assertTrue(owner.getListKost().contains(kost2));
    }
}