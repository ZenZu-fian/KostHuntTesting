package model;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestTenant {

    private Tenant tenant;

    @Before
    public void setUp() {
        tenant = new Tenant(1, "Andi", "andi@email.com", "password", "08123456789");
    }

    @Test
    public void testConstructorWithParameter() {
        assertEquals(1, tenant.getId());
        assertEquals("Andi", tenant.getName());
        assertEquals("andi@email.com", tenant.getEmail());
        assertEquals("08123456789", tenant.getPhone());
        assertEquals("Tenant", tenant.getRole());
    }

    @Test
    public void testMendaftarKost() {
        boolean result = tenant.mendaftarKost(
            1500000.0,
            101,
            "A1",
            tenant.getId()
        );

        assertTrue(result);
    }

    @Test
    public void testMencariKost() {
        String result = tenant.mencariKost(
            "Bandung",
            "1000000-2000000",
            "Jl. Merdeka"
        );

        assertNotNull(result);
        assertEquals("Hasil pencarian kost", result);
    }

    @Test
    public void testReview() {
        boolean result = tenant.review(
            1,
            tenant.getId(),
            10,
            "Kost nyaman",
            4.5
        );

        assertTrue(result);
    }

    @Test
    public void testMencariBuatPembayaran() {
        boolean result = tenant.mencariBuatPembayaran(
            "2025-01-01",
            tenant.getName(),
            "Owner A",
            1500000.0
        );

        assertTrue(result);
    }

    @Test
    public void testPay() {
        double amount = 2000000.0;
        Payment payment = tenant.pay(amount);

        assertNotNull(payment);
        assertEquals("Andi", payment.getTenantName());
        assertEquals(amount, payment.getAmount(), 0.001);
        assertNotNull(payment.getPaymentDate());
    }

    @Test
    public void testToString() {
        String result = tenant.toString();

        assertTrue(result.contains("Andi"));
        assertTrue(result.contains("andi@email.com"));
        assertTrue(result.contains("Tenant"));
    }
}
