package model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class PaymentTest {

    private Payment payment;

    @Before
    public void setUp() {
        payment = new Payment();
    }

    @Test
    public void testSetAndGetId() {
        payment.setId(1);
        assertEquals(1, payment.getId());
    }

    @Test
    public void testSetAndGetTenantName() {
        payment.setTenantName("Andi");
        assertEquals("Andi", payment.getTenantName());
    }

    @Test
    public void testSetAndGetAmount() {
        payment.setAmount(1000000.0);
        assertEquals(1000000.0, payment.getAmount(), 0.001);
    }

    @Test
    public void testSetAndGetPaymentDate() {
        payment.setPaymentDate("2025-01-10");
        assertEquals("2025-01-10", payment.getPaymentDate());
    }
}
