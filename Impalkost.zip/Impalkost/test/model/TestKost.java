package model;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestKost {

    private Kost kost;

    @Before
    public void setUp() {
        kost = new Kost();
    }

    @Test
    public void testSetAndGetName() {
        kost.setName("Kost Melati");
        assertEquals("Kost Melati", kost.getName());
    }

    @Test
    public void testSetAndGetAddress() {
        kost.setAddress("Jl. Merdeka No. 10");
        assertEquals("Jl. Merdeka No. 10", kost.getAddress());
    }

    @Test
    public void testSetAndGetLocation() {
        kost.setLocation("Bandung");
        assertEquals("Bandung", kost.getLocation());
    }

    @Test
    public void testSetAndGetDescription() {
        kost.setDescription("Dekat kampus");
        assertEquals("Dekat kampus", kost.getDescription());
    }

    @Test
    public void testSetAndGetType() {
        kost.setType("Putri");
        assertEquals("Putri", kost.getType());
    }

    @Test
    public void testSetAndGetFacilities() {
        kost.setFacilities("AC, WiFi");
        assertEquals("AC, WiFi", kost.getFacilities());
    }

    @Test
    public void testSetAndGetPrice() {
        kost.setPrice(1500000.0);
        assertEquals(1500000.0, kost.getPrice(), 0.001);
    }

    @Test
    public void testDefaultPriceIsZero() {
        assertEquals(0.0, kost.getPrice(), 0.001);
    }
}
