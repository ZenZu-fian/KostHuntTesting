package model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class RoomTest {

    private Room room;

    @Before
    public void setUp() {
        room = new Room();
    }

    @Test
    public void testSetAndGetId() {
        room.setId(10);
        assertEquals(10, room.getId());
    }

    @Test
    public void testSetAndGetNumber() {
        room.setNumber("A101");
        assertEquals("A101", room.getNumber());
    }

    @Test
    public void testSetAndGetType() {
        room.setType("Single");
        assertEquals("Single", room.getType());
    }

    @Test
    public void testSetAndGetKostId() {
        room.setKostId(5);
        assertEquals(5, room.getKostId());
    }

    @Test
    public void testSetAndGetKostName() {
        room.setKostName("Kost Maju Jaya");
        assertEquals("Kost Maju Jaya", room.getKostName());
    }

    @Test
    public void testSetAndGetPrice() {
        room.setPrice(750000.0);
        assertEquals(750000.0, room.getPrice(), 0.001);
    }

    @Test
    public void testSetAndGetStatus() {
        room.setStatus("Available");
        assertEquals("Available", room.getStatus());
    }

    @Test
    public void testSetAndGetRating() {
        room.setRating(4.5);
        assertEquals(4.5, room.getRating(), 0.001);
    }
}
