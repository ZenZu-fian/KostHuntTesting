package model;

/**
 * Base User class Simple POJO with business methods (no database operations)
 *
 * @author Ghaisani
 */
public class User {

    private int id;
    private String name;
    private String email;
    private String password;
    private String role;
    private String phone;

    // Default constructor
    public User() {
    }

    // Constructor with parameters
    public User(int id, String name, String email, String password, String phone, String role) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.role = role;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public static User loginPengguna(String email, String password) {
        System.out.println("loginPengguna called for: " + email);
        return null;
    }

    public static User registerPengguna(String email, String name, String phoneNumber, String password, String role) {
        System.out.println("registerPengguna called for: " + email);
        return null;
    }

    public boolean editProfil(String email, String name, String phoneNumber, String password, String role) {
        System.out.println("editProfil called for: " + this.email);

        this.email = email;
        this.name = name;
        this.phone = phoneNumber;
        this.role = role;
        if (password != null && !password.trim().isEmpty()) {
            this.password = password;
        }

        return true;
    }

    public void logoutPengguna() {
        System.out.println("User " + this.name + " (" + this.email + ") logged out");
    }

    @Override
    public String toString() {
        return "User{"
                + "id=" + id
                + ", name='" + name + '\''
                + ", email='" + email + '\''
                + ", role='" + role + '\''
                + ", phone='" + phone + '\''
                + '}';
    }
}
